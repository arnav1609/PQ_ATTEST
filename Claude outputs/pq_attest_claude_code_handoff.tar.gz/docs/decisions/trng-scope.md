# TRNG scope — what Stage 4 actually delivers

## Stage 4 is entropy conditioning + online health testing. There is no noise source.
**Chose:** state the scope honestly as "conditioning and health testing".
**Over:** describing the block as "a TRNG" in the README, paper, or CV.
**Because:** `trng_source.sv` replays a caller-supplied `entropy_vector`. There is no
ring oscillator, no metastability harvester, no jitter sampling. It also emits *bytes*
while `trng_top`/`trng_conditioner` consume 64-bit *words*, and it ignores
`entropy_ready` — so it cannot drive `trng_top` as written and is effectively orphaned.
A synthesized `trng_top` produces whatever its driver feeds it.
**Costs:** a weaker-sounding claim. In exchange, nothing in the write-up collapses when
a reviewer opens the file.
**Revisit if:** a real noise source is built. Ring-oscillator entropy on 7-series needs
`KEEP_HIERARCHY`, `DONT_TOUCH` and placement constraints or synthesis optimises the
loop away — that is a project of its own, not a file edit.

## What IS supportable today
Keccak-based conditioning of 512 raw bytes to 256 bits, padding and lane mapping
matching `trng_conditioning_ref.py` byte-for-byte, plus a per-byte-lane repetition-count
health monitor with sticky failure and abort/zeroize into the conditioner.
