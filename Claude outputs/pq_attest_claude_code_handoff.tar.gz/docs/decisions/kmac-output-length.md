# KMAC output length is absorbed, not truncated

## `out_len_sel` is a core input, not a Stage 5 wrapper concern
**Chose:** add `out_len_sel` to `kmac_encode` and `kmac_128`; `pq_kdf` drives it from
`key_len_sel`.
**Over:** generating a 256-bit tag always and slicing the low 128 bits in the KDF.
**Because:** KMAC absorbs `right_encode(L)`, so L changes the *message*:
`KMAC128(K,X,128) != KMAC128(K,X,256)[0:16]`. Verified against the project's own
vectors — `KMAC(V01 inputs, L=256)[:16]` = `f3d22e09…`, which is V06's prefix, while
the V01 golden is `9c699e78…`. `right_encode(128)` = `80 01` (2 bytes) and
`right_encode(256)` = `01 00 02` (3 bytes), so the differing width also moves the
KMAC domain byte that follows.
**Costs:** one extra input on two modules, and every instantiation must now drive it.
**Revisit if:** never — this is required by SP 800-185.

## Deliberately NOT given a default port value
A default would have silently restored old behaviour for an unconnected caller. For a
crypto core, a silently wrong domain separator yields a plausible-looking but
unverifiable tag. A hard break on an unconnected control input is the behaviour we
want. The cost is that every future instantiation must connect it — that is the
correct cost.
