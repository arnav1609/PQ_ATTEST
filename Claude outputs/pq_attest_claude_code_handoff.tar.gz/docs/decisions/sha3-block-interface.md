# SHA3-256 block-streaming interface

## Caller supplies one 136-byte block per `start`, with `valid_bytes` and `is_final`
**Chose:** keep the streaming interface; make its two failure modes loud.
**Over:** a one-shot interface buffering a whole message inside the core.
**Because:** message length is then unbounded by the core (correcting an earlier claim
that SHA3 was capped at 272 bytes — that limit belonged to `rtl/sha3/sha3_256_core.sv`
in the reference zip, not to the project's `SHA3_256.sv`). Buffering a 4 KB message
inside the core would cost BRAM for no benefit.
**Costs:** the caller carries the padding contract, and two hold requirements.
Both are now enforced rather than assumed:
- `is_final` is **latched at accept** (it was read live in `KECCAK_WAIT`, ~26 cycles
  after `start`; dropping it early silently produced no digest and no error).
- `is_final && valid_bytes == RATE_BYTES` now **asserts**. `sha3_pad` only pads when
  `valid_bytes < RATE_BYTES`, so a full final block previously received no padding at
  all and emitted a wrong digest with nothing visible in a waveform. FIPS 202 requires
  an extra all-padding block; the contract is `valid_bytes=0, is_final=1`.
**Revisit if:** a consumer needs fire-and-forget hashing — then add a wrapper FSM that
owns the blocking, rather than changing this core.
