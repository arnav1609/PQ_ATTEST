# Byte order across the crypto lane

## One packing convention, chosen at the producer
**Chose:** byte *i* of every digest, tag and key lives at `[i*8 +: 8]` (byte 0 at the LSB end).
**Over:** (a) SHA3's original packing, byte 0 at the MSB end; (b) leaving both and
swapping at each consumer.
**Because:** `kmac_128`, `trng_conditioner` and `pq_kdf` already used LSB-first; only
`sha3_256` did not. In Stage 6 the SHA3 digest becomes part of a KMAC *message*, and
`kmac128.msg_in` is LSB-first — so the mismatch would have produced a wrong tag with
every unit test still green. Fixing one producer beats fixing every future consumer.
**Costs:** SHA3 digests no longer print in NIST order straight from the register.
`SHA3_TB` carries a `bswap256` adapter so the KAT literals stay human-checkable
against published vectors. Any future consumer that wants printed order pays a swap.
**Revisit if:** an external interface (UART dump, AXI map, host driver) forces
big-endian on the boundary — then swap once at that boundary, not inside the core.

## Evidence this was real, not theoretical
`kmac_tb` and `TRNG_TB` golden literals only reproduce from the Python reference when
byte-reversed; `SHA3_TB`'s only reproduce when not. Confirmed against the RTL source
of both squeeze blocks, not inferred.

## Consequence for Stage 5
`kdf_vectors.txt` stores printed order; `pq_kdf.derived_key` is LSB-first. The Stage 5
testbench must byte-swap on load. A wrong swap fails all six vectors identically and
looks exactly like a broken KDF — so `pq_kdf_tb` self-tests the swap against a
hand-computed anchor before running a single vector. A round-trip test alone is
insufficient: it also passes if the swap function is the identity.
