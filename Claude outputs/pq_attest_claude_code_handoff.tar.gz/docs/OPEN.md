# Open threads — PQ-Attest

## Now
- [ ] `pq_kdf` has **never been elaborated**. Run `pq_kdf_tb`; the bswap self-test
      is the first gate, the six golden vectors the second.
- [ ] Re-run `kmac_tb` after the Stage 5 fileset change. Must stay 10/10.

## Cheap, high-value
- [ ] **Add a mutation/negative-control pass to `SHA3_TB`, `kmac_tb` and `TRNG_TB`.**
      `pq_keccak_tb` already has one — copy the pattern. Until then none of those
      three can answer "how do you know your testbench can fail?", and none is
      honestly `sim-verified`. Cheapest upgrade in the project.
- [ ] Add an **L=128 KAT to `kmac_tb`**. `out_len_sel` low is currently untested;
      the one path Stage 5 depends on most is the one with no KAT.
- [ ] `pq_keccak_tb` drives only the all-zero input. Add random-input vectors.
- [ ] `pq_kdf_tb` covers context lengths {0, 13, 14} only. Add 1-12.

## Housekeeping
- [ ] Delete `kmac_pkg.sv.bak`, `kmac_encode.sv.bak`, `kmac_128.sv.bak` once Stage 5
      is green. They are the only rollback until then.
- [ ] Remove orphans from the fileset (keep on disk): `pq_kdf_sp800185_encoder.sv`,
      `pq_kdf_message_builder.sv`, `TRNG_PAD.sv`.

## Unresolved / unexplained
- [ ] `NOC_PKG.sv` shrank 30,144 → 20,347 bytes at some point. Never explained.
      Check `git log` or a backup before trusting the NoC lane.
- [ ] Unknown whether the M10 5-hunk `rx_head_shape_ok` patch was ever applied.
- [ ] Stage 8 nonce origin (verifier-issued vs tile-generated) is still undecided,
      and it determines whether a real entropy source is in scope at all.

## NoC lane — ON HOLD
M10 Phase-5 completion and M11 integration are parked while the crypto lane closes.
