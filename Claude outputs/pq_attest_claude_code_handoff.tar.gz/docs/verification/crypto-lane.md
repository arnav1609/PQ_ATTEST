# Verification status — PQ-Attest crypto lane

Toolchain: Vivado 2024.1 / XSim · xc7a100tcsg324-1 · Arty A7-100T
Last updated: 2026-09-15

Status ladder: unwritten → lint-clean → smoke → sim-verified → formally-proven → hw-validated
`sim-verified` requires ALL THREE: independent golden model, stated stimulus
strategy, and mutation testing that shows the TB catches injected bugs.

| Module | Status | Evidence | What blocks the next rung |
|---|---|---|---|
| `keccak_theta/rho/pi/chi/iota` | **sim-verified** | Step-level formulas transcribed from RTL and checked against `keccak_ref.py` over 200 random states each | — |
| `keccak_f1600` | **sim-verified** *(narrow stimulus)* | 600 per-round golden lanes from `keccak_ref.py`; negative control (1-bit flip) detected | Stimulus is the all-zero input only. Add random-input vectors. |
| `sha3_256` | **smoke** | 49 checks; 6 KATs independently reproduced from `hashlib.sha3_256`; boundaries 0/3/11/135/136/137 | **No mutation testing.** One mutation pass upgrades this to sim-verified. |
| `sha3_pad` / `sha3_absorb` | **smoke** | Exercised only through `sha3_256`; padding bytes checked directly via `dut.padded_block` | No standalone TB, no mutation pass |
| `kmac_encode` | **smoke** | Exercised only through `kmac128` | No standalone TB, no mutation pass |
| `kmac128` | **smoke** | 10/10; all 5 tags independently reproduced from `kmac128_ref.py`; reference itself reproduces the NIST SP 800-185 KAT; 3-permutation structural check | **No mutation testing.** No L=128 KAT — `out_len_sel` low is untested. |
| `trng_conditioner` | **smoke** | 5 conditioned outputs + nonces independently reproduced from `trng_conditioning_ref.py` | No mutation pass |
| `trng_health` | **smoke** | Repetition-count threshold exercised in TRNG_TB | No independent model; Python side has no matching online health test |
| `trng_source` | **not a design module** | Vector replayer, not an entropy source | See decisions/trng-scope.md |
| `pq_kdf` | **BELOW lint-clean** | RTL written; **never elaborated** | Has not compiled once. `pq_kdf_tb` is the first gate. |
| `pq_kdf_pkg` | lint-clean | Parameters hand-checked against `pq_kdf_pkg` ↔ reference field widths | — |

## Flagged as overstated

- **"Stage 2/3/4 PASS" banners print in the testbench logs.** Those banners mean
  *the vectors pass*, which is real and independently confirmed. They do not mean
  `sim-verified` — none of those three testbenches does mutation testing. A
  reviewer who asks "how do you know your testbench can fail?" has no answer for
  SHA3, KMAC or TRNG today. The Keccak TB does have a negative control; the others
  should copy it. This is the cheapest upgrade available in the whole project.
- **"PQ-Attest has a TRNG"** is not supportable. See decisions/trng-scope.md.
