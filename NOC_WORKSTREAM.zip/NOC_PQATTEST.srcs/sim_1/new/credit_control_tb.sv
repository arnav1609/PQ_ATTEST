//=============================================================================
// Testbench : tb_noc_credit_control.sv
// Module    : M9 noc_credit_control
//
// Verification:
//     - Reset initialization
//     - Credit decrement
//     - Credit increment
//     - Zero-credit blocking
//     - Simultaneous send + return
//     - All 15 output/VC channels
//     - Randomized stress
//     - SVA
//=============================================================================

`timescale 1ns/1ps

module tb_noc_credit_control;

    import noc_pkg::*;

    //=========================================================================
    // PARAMETERS
    //=========================================================================

    localparam int NUM_INPUT_VCS = NUM_PORTS * NUM_VC;
    localparam int INPUT_VC_W =
        (NUM_INPUT_VCS <= 1) ? 1 : $clog2(NUM_INPUT_VCS);

    //=========================================================================
    // CLOCK / RESET
    //=========================================================================

    logic clk;
    logic rst;

    initial clk = 1'b0;

    always #5 clk = ~clk;

    //=========================================================================
    // DUT INPUTS
    //=========================================================================

    logic [NUM_INPUT_VCS-1:0] grant [NUM_PORTS];

    logic [NUM_PORTS-1:0] grant_valid;

    logic [INPUT_VC_W-1:0] xbar_sel [NUM_PORTS];

    logic [NUM_VC-1:0] credit_return [NUM_PORTS];

    //=========================================================================
    // DUT OUTPUTS
    //=========================================================================

    logic [NUM_PORTS-1:0] credit_ok;

    logic [NUM_PORTS-1:0] grant_valid_qualified;

    logic [NUM_INPUT_VCS-1:0] fifo_rd_en;

    //=========================================================================
    // DUT
    //=========================================================================

    noc_credit_control dut (

        .clk                    (clk),
        .rst                    (rst),

        .grant                  (grant),
        .grant_valid            (grant_valid),
        .xbar_sel               (xbar_sel),

        .credit_return          (credit_return),

        .credit_ok              (credit_ok),
        .grant_valid_qualified (grant_valid_qualified),
        .fifo_rd_en             (fifo_rd_en)

    );

    //=========================================================================
    // HELPER TASKS
    //=========================================================================

    task automatic clear_inputs;

        begin

            grant_valid = '0;

            for (int p = 0; p < NUM_PORTS; p++) begin

                grant[p] = '0;
                xbar_sel[p] = '0;
                credit_return[p] = '0;

            end

        end

    endtask


    //-------------------------------------------------------------------------
    // Create one legal M7 grant.
    //
    // output_port = physical output
    // input_vc    = global input VC 0..14
    //-------------------------------------------------------------------------

    task automatic drive_grant(
        input int output_port,
        input int input_vc
    );

        begin

            clear_inputs();

            grant_valid[output_port] = 1'b1;

            grant[output_port][input_vc] = 1'b1;

            xbar_sel[output_port] = INPUT_VC_W'(input_vc);

        end

    endtask


    task automatic no_grant;

        begin
            clear_inputs();
        end

    endtask


    //-------------------------------------------------------------------------
    // Return one credit.
    //
    // output_port = sender's output
    // vc          = VC on that link
    //-------------------------------------------------------------------------

    task automatic return_credit(
        input int output_port,
        input int vc
    );

        begin

            credit_return[output_port][vc] = 1'b1;

        end

    endtask


    //=========================================================================
    // CHECK CREDIT
    //=========================================================================

    task automatic check_credit(
        input int output_port,
        input int vc,
        input int expected
    );

        int actual;

        begin

            actual = dut.credit_count[output_port][vc];

            if (actual !== expected) begin

                $error(
                    "CREDIT MISMATCH: P=%0d VC=%0d expected=%0d actual=%0d",
                    output_port,
                    vc,
                    expected,
                    actual
                );

            end
            else begin

                $display(
                    "[PASS] credit P=%0d VC=%0d = %0d",
                    output_port,
                    vc,
                    actual
                );

            end

        end

    endtask


    //=========================================================================
    // RESET TEST
    //=========================================================================

    task automatic test_reset;

        begin

            $display("\n========================================");
            $display("TEST 1: RESET INITIALIZATION");
            $display("========================================");

            rst = 1'b1;

            clear_inputs();

            repeat (2) @(posedge clk);

            rst = 1'b0;

            @(posedge clk);

            for (int p = 0; p < NUM_PORTS; p++) begin

                check_credit(p, 0, VC0_DEPTH);
                check_credit(p, 1, VC1_DEPTH);
                check_credit(p, 2, VC2_DEPTH);

            end

        end

    endtask


    //=========================================================================
    // SINGLE SEND TEST
    //=========================================================================

    task automatic test_single_send;

        begin

            $display("\n========================================");
            $display("TEST 2: SINGLE SEND");
            $display("========================================");

            drive_grant(2, 0);

            @(posedge clk);

            #1;

            check_credit(2, 0, VC0_DEPTH - 1);

            if (!grant_valid_qualified[2])
                $error("M9: legal send was incorrectly blocked");

            if (!fifo_rd_en[0])
                $error("M9: FIFO read enable missing");

        end

    endtask


    //=========================================================================
    // EXHAUST CREDIT TEST
    //=========================================================================

    task automatic test_exhaust_credit;

        begin

            $display("\n========================================");
            $display("TEST 3: EXHAUST CREDIT");
            $display("========================================");

            clear_inputs();

            // Four sends.
            for (int k = 0; k < VC0_DEPTH; k++) begin

                drive_grant(0, 0);

                @(posedge clk);

                #1;

            end

            check_credit(0, 0, 0);

            // Credit is now zero.
            drive_grant(0, 0);

            #1;

            if (grant_valid_qualified[0] !== 1'b0)
                $error("M9: ZERO CREDIT DID NOT BLOCK SEND");

            if (fifo_rd_en[0] !== 1'b0)
                $error("M9: FIFO READ OCCURRED WITH ZERO CREDIT");

            $display("[PASS] Zero-credit blocking");

        end

    endtask


    //=========================================================================
    // CREDIT RETURN TEST
    //=========================================================================

    task automatic test_credit_return;

        begin

            $display("\n========================================");
            $display("TEST 4: CREDIT RETURN");
            $display("========================================");

            clear_inputs();

            return_credit(0, 0);

            @(posedge clk);

            #1;

            check_credit(0, 0, 1);

            // Now one send must be possible.
            drive_grant(0, 0);

            #1;

            if (!grant_valid_qualified[0])
                $error("M9: returned credit was not usable");

            @(posedge clk);

            #1;

            check_credit(0, 0, 0);

        end

    endtask


    //=========================================================================
    // SIMULTANEOUS SEND + RETURN
    //=========================================================================

    task automatic test_send_return_same_cycle;

        begin

            $display("\n========================================");
            $display("TEST 5: SEND + CREDIT RETURN");
            $display("========================================");

            // First create credit = 1.
            clear_inputs();

            return_credit(1, 1);

            @(posedge clk);

            #1;

            check_credit(1, 1, 1);

            // Send and return on same cycle.
            drive_grant(1, 4);       // VC4 => VC1

            credit_return[1][1] = 1'b1;

            #1;

            if (!grant_valid_qualified[1])
                $error("M9: simultaneous send/return incorrectly blocked");

            @(posedge clk);

            #1;

            // Net change must be zero.
            check_credit(1, 1, 1);

            $display("[PASS] Simultaneous send + return");

        end

    endtask


    //=========================================================================
    // ALL 15 CHANNELS
    //=========================================================================

    task automatic test_all_channels;

        int global_vc;

        begin

            $display("\n========================================");
            $display("TEST 6: ALL 15 OUTPUT x VC CHANNELS");
            $display("========================================");

            for (int p = 0; p < NUM_PORTS; p++) begin

                for (int v = 0; v < NUM_VC; v++) begin

                    global_vc = p * NUM_VC + v;

                    drive_grant(p, global_vc);

                    @(posedge clk);

                    #1;

                    if (!grant_valid_qualified[p]) begin

                        $error(
                            "M9: channel P=%0d VC=%0d unexpectedly blocked",
                            p, v
                        );

                    end

                end

            end

            $display("[PASS] All 15 channels exercised");

        end

    endtask


    //=========================================================================
    // RANDOM STRESS
    //=========================================================================

    task automatic random_stress;

        int p;
        int vc;
        int input_vc;
        int operation;

        begin

            $display("\n========================================");
            $display("TEST 7: RANDOMIZED CREDIT STRESS");
            $display("========================================");

            clear_inputs();

            repeat (5000) begin

                clear_inputs();

                p = $urandom_range(0, NUM_PORTS-1);
                vc = $urandom_range(0, NUM_VC-1);

                operation = $urandom_range(0, 2);

                if (operation == 0) begin

                    //-----------------------------------------------------------------
                    // No operation
                    //-----------------------------------------------------------------

                end
                else if (operation == 1) begin

                    //-----------------------------------------------------------------
                    // Credit return
                    //-----------------------------------------------------------------

                    credit_return[p][vc] = 1'b1;

                end
                else begin

                    //-----------------------------------------------------------------
                    // Send.
                    //
                    // Select a global input VC whose VC matches vc.
                    //-----------------------------------------------------------------

                    input_vc = $urandom_range(0, NUM_PORTS-1) * NUM_VC + vc;

                    grant_valid[p] = 1'b1;
                    grant[p][input_vc] = 1'b1;
                    xbar_sel[p] = INPUT_VC_W'(input_vc);

                end

                @(posedge clk);

            end

            clear_inputs();

            $display("[PASS] 5000-cycle randomized stress completed");

        end

    endtask


    //=========================================================================
    // NEGATIVE CONTROL
    //
    // Deliberately violate M7's one-hot grant contract.
    //
    // The DUT assertion p_one_hot_grant MUST fire.
    //
    // Do this only after the normal tests.
    //=========================================================================

    task automatic negative_control;

        begin

            $display("\n========================================");
            $display("TEST 8: NEGATIVE CONTROL");
            $display("========================================");

            clear_inputs();

            grant_valid[0] = 1'b1;

            grant[0][0] = 1'b1;
            grant[0][1] = 1'b1;

            xbar_sel[0] = INPUT_VC_W'(0);

            @(posedge clk);

            $display(
                "EXPECTED: M9 one-hot assertion should report this illegal grant."
            );

            clear_inputs();

        end

    endtask


    //=========================================================================
    // TEST SEQUENCE
    //=========================================================================

    initial begin

        $display("\n");
        $display("======================================================");
        $display(" PQ-ATTEST NOC : M9 CREDIT CONTROL VERIFICATION");
        $display("======================================================");

        rst = 1'b0;

        clear_inputs();

        test_reset();

        test_single_send();

        test_exhaust_credit();

        test_credit_return();

        test_send_return_same_cycle();

        test_all_channels();

        random_stress();

        negative_control();

        #20;

        $display("\n======================================================");
        $display(" M9 TESTBENCH COMPLETE");
        $display("======================================================");

        $finish;

    end

endmodule