
// File        : noc_network_interface.sv
// Module      : noc_network_interface   (M10)
// Project     : PQ-Attest NoC
//
// M10 RESPONSIBILITIES
//   - Serialise a tile transaction into a NoC packet:
//       HEAD + PAYLOAD + optional MAC
//   - Deserialise incoming NoC packets back into tile transactions
//   - Select VC from message type
//   - Hardwire source coordinates from LOCAL_TILE_ID
//   - Enforce packet length and packet-shape correctness
//   - Reject packets not addressed to this tile
//   - Track up to N_OUTSTANDING remote memory transactions
//   - Allocate a transaction tag from the outstanding-table slot
//   - Carry transaction tag in head_flit.control[0]
//   - Match memory responses using:
//       response tag
//       response source coordinate
//       response message type
//   - Consume malformed/unmatched responses instead of stalling the fabric
//
// TRANSACTION TAG
//   N_OUTSTANDING = 2
//   TXN_TAG_WIDTH = $clog2(2) = 1
//   tag            = control[0]
//
// IMPORTANT:
//   M10 owns the transaction tag. The CPU does NOT provide it.
//
//   Request:
//       CPU -> M10
//             M10 allocates slot 0/1
//             tag = slot number
//             tag inserted into control[0]
//
//   Response:
//       NoC -> M10
//             extract control[0]
//             find outstanding slot
//             verify source == original destination
//             verify response type
//             deliver response
//             free slot only after complete packet
//
// SECURITY NOTE:
//   The source-coordinate check is NOT cryptographic authentication.
//   A compromised destination tile could still forge its own response.
//   L2 MAC authentication in M13 is what closes that gap.
//
// Target:
//   xc7a100tcsg324-1, Vivado 2024.1
//=============================================================================

`timescale 1ns/1ps

module noc_network_interface #(
    parameter int LOCAL_TILE_ID = 0
) (
    input  logic clk,
    input  logic rst,

    //=========================================================================
    // TILE -> NoC : transaction request
    //=========================================================================

    input  logic                           tx_valid,
    output logic                           tx_ready,

    input  noc_pkg::coord_t                tx_dest_coord,
    input  noc_pkg::msg_type_e             tx_msg_type,
    input  logic [10:0]                    tx_control,

    input  logic [noc_pkg::FLIT_WIDTH-1:0] tx_payload_data,
    input  logic                           tx_payload_valid,
    output logic                           tx_payload_ready,

    input  logic [noc_pkg::MAC_TAG_BITS-1:0] tx_mac_tag,

    output logic                           tx_error,

    //=========================================================================
    // NoC egress
    //=========================================================================

    output noc_pkg::flit_t                 noc_tx_flit,
    output logic                           noc_tx_valid,
    input  logic                           noc_tx_ready,

    //=========================================================================
    // NoC ingress
    //=========================================================================

    input  noc_pkg::flit_t                 noc_rx_flit,
    input  logic                           noc_rx_valid,
    output logic                           noc_rx_ready,

    //=========================================================================
    // NoC -> TILE : received transaction
    //=========================================================================

    output noc_pkg::coord_t                rx_src_coord,
    output noc_pkg::coord_t                rx_dest_coord,
    output noc_pkg::msg_type_e             rx_msg_type,
    output logic [10:0]                    rx_control,
    output logic [4:0]                     rx_length,
    output logic                           rx_head_valid,

    output logic [noc_pkg::FLIT_WIDTH-1:0] rx_payload_data,
    output logic                           rx_payload_valid,
    output logic                           rx_payload_last,
    input  logic                           rx_ready,

    output logic [noc_pkg::MAC_TAG_BITS-1:0] rx_mac_tag,
    output logic                           rx_mac_valid,

    output logic                           rx_protocol_error,
    output logic                           rx_length_error,

    //=========================================================================
    // Status
    //=========================================================================

    output logic                           tx_busy,
    output logic                           rx_busy
);

    import noc_pkg::*;

    //=========================================================================
    // Local constants
    //=========================================================================

    localparam tile_id_e LOCAL_TILE =
        tile_id_e'(LOCAL_TILE_ID[TILE_ID_WIDTH-1:0]);

    localparam coord_t LOCAL_COORD =
        tile_to_coord(LOCAL_TILE);

    localparam int unsigned MAC_CNT_WIDTH =
        (MAC_FLITS_FULL <= 1) ? 1 : $clog2(MAC_FLITS_FULL + 1);

    //=========================================================================
    // Transaction tracking
    //=========================================================================

    logic [N_OUTSTANDING-1:0] txn_valid_q;

    coord_t txn_dest_q [N_OUTSTANDING];

    msg_type_e txn_resp_type_q [N_OUTSTANDING];

    logic [TXN_TAG_WIDTH-1:0] tx_alloc_tag;
    logic                      tx_slot_available;

    logic [TXN_TAG_WIDTH-1:0] rx_resp_tag;
    logic                      rx_response_match;
    logic [TXN_TAG_WIDTH-1:0] rx_match_slot;

    logic rx_is_mem_response;

    //=========================================================================
    // Find lowest-numbered free outstanding slot.
    //=========================================================================

    always_comb begin

        tx_slot_available = 1'b0;
        tx_alloc_tag      = '0;

        for (int i = 0; i < N_OUTSTANDING; i++) begin

            if (!txn_valid_q[i] && !tx_slot_available) begin

                tx_slot_available = 1'b1;
                tx_alloc_tag      = TXN_TAG_WIDTH'(i);

            end

        end

    end

    //=========================================================================
    // TX state
    //=========================================================================

    typedef enum logic [1:0] {
        TX_IDLE    = 2'd0,
        TX_HEAD    = 2'd1,
        TX_PAYLOAD = 2'd2,
        TX_MAC     = 2'd3
    } tx_state_e;

    tx_state_e tx_state_q;
    tx_state_e tx_state_d;

    coord_t                   tx_dest_q;
    msg_type_e                tx_msg_q;
    logic [10:0]              tx_control_q;
    logic [4:0]               tx_payload_n_q;
    logic [4:0]               tx_payload_cnt_q;
    logic [MAC_CNT_WIDTH-1:0] tx_mac_cnt_q;
    logic [MAC_TAG_BITS-1:0]  tx_mac_tag_q;

    vc_e        tx_vc;
    head_flit_t tx_head;

    logic tx_dest_ok;
    logic tx_single;
    logic tx_last_payload;
    logic tx_last_mac;

    //=========================================================================
    // RX state
    //=========================================================================

    typedef enum logic [1:0] {
        RX_IDLE    = 2'd0,
        RX_PAYLOAD = 2'd1,
        RX_MAC     = 2'd2
    } rx_state_e;

    rx_state_e rx_state_q;
    rx_state_e rx_state_d;

    coord_t                   rx_src_q;
    coord_t                   rx_dest_q;
    msg_type_e                rx_msg_q;
    logic [10:0]              rx_control_q;
    logic [4:0]               rx_length_q;
    logic [4:0]               rx_payload_n_q;
    logic [4:0]               rx_payload_cnt_q;
    logic [MAC_CNT_WIDTH-1:0] rx_mac_cnt_q;
    logic [MAC_TAG_BITS-1:0]  rx_mac_tag_q;

    head_flit_t rx_head;

    logic       rx_is_head;
    logic       rx_is_head_tail;
    logic       rx_head_for_us;
    logic       rx_head_len_ok;
    logic       rx_head_shape_ok;
    logic [4:0] rx_head_payload_n;

    //=========================================================================
    // TX PATH
    //=========================================================================

    assign tx_dest_ok = valid_coord(tx_dest_coord);

    assign tx_vc = message_to_vc(tx_msg_q);

    assign tx_single =
        (tx_payload_n_q == 5'd0) &&
        (MAC_FLITS == 0);

    assign tx_last_payload =
        (tx_payload_cnt_q + 5'd1) >= tx_payload_n_q;

    assign tx_last_mac =
        (MAC_FLITS != 0) &&
        ((tx_mac_cnt_q + MAC_CNT_WIDTH'(1)) >=
         MAC_CNT_WIDTH'(MAC_FLITS));

    //=========================================================================
    // TX head construction
    //=========================================================================

    always_comb begin

        tx_head             = '0;

        tx_head.dest_x      = tx_dest_q.x;
        tx_head.dest_y      = tx_dest_q.y;

        tx_head.src_x       = LOCAL_COORD.x;
        tx_head.src_y       = LOCAL_COORD.y;

        tx_head.msg_type    = tx_msg_q;
        tx_head.length      = message_length(tx_msg_q);

        tx_head.control.raw = tx_control_q;

    end

    //=========================================================================
    // TX outputs
    //=========================================================================

    always_comb begin

        noc_tx_flit      = '0;
        noc_tx_valid     = 1'b0;

        tx_ready         = 1'b0;
        tx_payload_ready = 1'b0;

        tx_error         = 1'b0;

        unique case (tx_state_q)

            TX_IDLE: begin

                if ((tx_msg_type == MSG_MEM_RD_REQ) ||
                    (tx_msg_type == MSG_MEM_WR_REQ)) begin

                    tx_ready = tx_slot_available;

                end
                else begin

                    tx_ready = 1'b1;

                end

                tx_error =
                    tx_valid &&
                    !tx_dest_ok;

            end

            TX_HEAD: begin

                noc_tx_valid          = 1'b1;

                noc_tx_flit.flit_data = tx_head;

                noc_tx_flit.flit_type =
                    tx_single ? FLIT_HEAD_TAIL : FLIT_HEAD;

                noc_tx_flit.vc_id =
                    tx_vc;

            end

            TX_PAYLOAD: begin

                noc_tx_valid          = tx_payload_valid;

                noc_tx_flit.flit_data = tx_payload_data;

                noc_tx_flit.flit_type =
                    (tx_last_payload && (MAC_FLITS == 0))
                    ? FLIT_TAIL
                    : FLIT_BODY;

                noc_tx_flit.vc_id =
                    tx_vc;

                tx_payload_ready =
                    noc_tx_ready;

            end

            TX_MAC: begin

                noc_tx_valid = 1'b1;

                noc_tx_flit.flit_data =
                    tx_mac_tag_q[
                        {tx_mac_cnt_q, 5'd0} +: FLIT_WIDTH
                    ];

                noc_tx_flit.flit_type =
                    tx_last_mac
                    ? FLIT_TAIL
                    : FLIT_BODY;

                noc_tx_flit.vc_id =
                    tx_vc;

            end

            default: begin

                noc_tx_valid = 1'b0;

            end

        endcase

    end

    //=========================================================================
    // TX next-state
    //=========================================================================

    always_comb begin

        tx_state_d = tx_state_q;

        unique case (tx_state_q)

            TX_IDLE: begin

                if (tx_valid &&
                    tx_ready &&
                    tx_dest_ok) begin

                    tx_state_d = TX_HEAD;

                end

            end

            TX_HEAD: begin

                if (noc_tx_valid && noc_tx_ready) begin

                    if (tx_single)
                        tx_state_d = TX_IDLE;

                    else if (tx_payload_n_q != 5'd0)
                        tx_state_d = TX_PAYLOAD;

                    else
                        tx_state_d = TX_MAC;

                end

            end

            TX_PAYLOAD: begin

                if (noc_tx_valid &&
                    noc_tx_ready &&
                    tx_last_payload) begin

                    tx_state_d =
                        (MAC_FLITS != 0)
                        ? TX_MAC
                        : TX_IDLE;

                end

            end

            TX_MAC: begin

                if (noc_tx_valid &&
                    noc_tx_ready &&
                    tx_last_mac) begin

                    tx_state_d = TX_IDLE;

                end

            end

            default: begin

                tx_state_d = TX_IDLE;

            end

        endcase

    end

    //=========================================================================
    // TX registers
    //=========================================================================

    always_ff @(posedge clk) begin

        if (rst) begin

            tx_state_q       <= TX_IDLE;

            tx_dest_q        <= '0;
            tx_msg_q         <= MSG_MEM_RD_REQ;
            tx_control_q     <= '0;

            tx_payload_n_q   <= '0;
            tx_payload_cnt_q <= '0;

            tx_mac_cnt_q     <= '0;
            tx_mac_tag_q     <= '0;

        end
        else begin

            tx_state_q <= tx_state_d;

            //-----------------------------------------------------------------
            // Accept new transaction
            //-----------------------------------------------------------------

            if ((tx_state_q == TX_IDLE) &&
                tx_valid &&
                tx_ready &&
                tx_dest_ok) begin

                tx_dest_q    <= tx_dest_coord;
                tx_msg_q     <= tx_msg_type;

                tx_control_q <= tx_control;

                tx_payload_n_q <=
                    message_payload_flits(tx_msg_type);

                tx_payload_cnt_q <= '0;
                tx_mac_cnt_q     <= '0;

                tx_mac_tag_q <= tx_mac_tag;

                //-----------------------------------------------------------------
                // Allocate tag for memory requests.
                //-----------------------------------------------------------------

                if ((tx_msg_type == MSG_MEM_RD_REQ) ||
                    (tx_msg_type == MSG_MEM_WR_REQ)) begin

                    tx_control_q[TXN_TAG_WIDTH-1:0]
                        <= tx_alloc_tag;

                end

            end

            //-----------------------------------------------------------------
            // Payload counter
            //-----------------------------------------------------------------

            if ((tx_state_q == TX_PAYLOAD) &&
                noc_tx_valid &&
                noc_tx_ready) begin

                tx_payload_cnt_q <=
                    tx_payload_cnt_q + 5'd1;

            end

            //-----------------------------------------------------------------
            // MAC counter
            //-----------------------------------------------------------------

            if ((tx_state_q == TX_MAC) &&
                noc_tx_valid &&
                noc_tx_ready) begin

                tx_mac_cnt_q <=
                    tx_mac_cnt_q + MAC_CNT_WIDTH'(1);

            end

        end

    end

    //=========================================================================
    // Outstanding transaction table
    //
    // FIX:
    // The response HEAD is only on noc_rx_flit during RX_IDLE.
    //
    // Once the HEAD has been consumed, the subsequent TAIL/MAC flits contain
    // payload/MAC data, NOT header data. Therefore response completion for
    // multi-flit packets uses rx_msg_q and rx_control_q, which were captured
    // from the accepted HEAD.
    //=========================================================================

    always_ff @(posedge clk) begin

        if (rst) begin

            for (int i = 0; i < N_OUTSTANDING; i++) begin

                txn_valid_q[i] <= 1'b0;

                txn_dest_q[i] <= '0;

                txn_resp_type_q[i] <=
                    MSG_MEM_RD_RESP;

            end

        end
        else begin

            //-----------------------------------------------------------------
            // Allocate slot when memory request is accepted.
            //-----------------------------------------------------------------

            if ((tx_state_q == TX_IDLE) &&
                tx_valid &&
                tx_ready &&
                tx_dest_ok &&
                ((tx_msg_type == MSG_MEM_RD_REQ) ||
                 (tx_msg_type == MSG_MEM_WR_REQ))) begin

                txn_valid_q[tx_alloc_tag] <= 1'b1;

                txn_dest_q[tx_alloc_tag] <=
                    tx_dest_coord;

                if (tx_msg_type == MSG_MEM_RD_REQ) begin

                    txn_resp_type_q[tx_alloc_tag] <=
                        MSG_MEM_RD_RESP;

                end
                else begin

                    txn_resp_type_q[tx_alloc_tag] <=
                        MSG_MEM_WR_RESP;

                end

            end

            //-----------------------------------------------------------------
            // CASE 1:
            // Single-flit memory response.
            //
            // HEAD_TAIL contains the complete packet, so the live header is
            // still available on noc_rx_flit.
            //-----------------------------------------------------------------

            if ((rx_state_q == RX_IDLE) &&
                rx_is_head_tail &&
                rx_head_for_us &&
                rx_head_shape_ok &&
                rx_is_mem_response &&
                rx_response_match &&
                noc_rx_ready) begin

                txn_valid_q[rx_match_slot] <= 1'b0;

            end

            //-----------------------------------------------------------------
            // CASE 2:
            // Multi-flit memory response with MAC disabled.
            //
            // The packet HEAD has already been consumed. The current flit is
            // the payload TAIL, so DO NOT use rx_head/rx_response_match here.
            //
            // Use the registered metadata captured from the HEAD.
            //-----------------------------------------------------------------

            else if ((rx_state_q == RX_PAYLOAD) &&
                     noc_rx_valid &&
                     noc_rx_ready &&
                     (noc_rx_flit.flit_type == FLIT_TAIL) &&
                     (MAC_FLITS == 0)) begin

                if ((rx_msg_q == MSG_MEM_RD_RESP) ||
                    (rx_msg_q == MSG_MEM_WR_RESP)) begin

                    txn_valid_q[
                        rx_control_q[TXN_TAG_WIDTH-1:0]
                    ] <= 1'b0;

                end

            end

            //-----------------------------------------------------------------
            // CASE 3:
            // MAC-enabled response.
            //
            // The final MAC flit completes the packet. Again, use the
            // registered response metadata because the current wire data is
            // MAC data rather than the header.
            //-----------------------------------------------------------------

            else if ((rx_state_q == RX_MAC) &&
                     noc_rx_valid &&
                     noc_rx_ready &&
                     ((rx_mac_cnt_q + MAC_CNT_WIDTH'(1)) >=
                      MAC_CNT_WIDTH'(MAC_FLITS))) begin

                if ((rx_msg_q == MSG_MEM_RD_RESP) ||
                    (rx_msg_q == MSG_MEM_WR_RESP)) begin

                    txn_valid_q[
                        rx_control_q[TXN_TAG_WIDTH-1:0]
                    ] <= 1'b0;

                end

            end

        end

    end

    //=========================================================================
    // RX PATH
    //=========================================================================

    assign rx_head =
        head_flit_t'(noc_rx_flit.flit_data);

    assign rx_is_head =
        noc_rx_valid &&
        (noc_rx_flit.flit_type == FLIT_HEAD);

    assign rx_is_head_tail =
        noc_rx_valid &&
        (noc_rx_flit.flit_type == FLIT_HEAD_TAIL);

    //-------------------------------------------------------------------------
    // Destination check
    //-------------------------------------------------------------------------

    assign rx_head_for_us =
        (rx_head.dest_x == LOCAL_COORD.x) &&
        (rx_head.dest_y == LOCAL_COORD.y);

    //-------------------------------------------------------------------------
    // Expected payload count
    //-------------------------------------------------------------------------

    assign rx_head_payload_n =
        message_payload_flits(rx_head.msg_type);

    //-------------------------------------------------------------------------
    // Length validation
    //-------------------------------------------------------------------------

    assign rx_head_len_ok =
        (rx_head.length ==
         (5'd1 +
          rx_head_payload_n +
          MAC_FLITS));

    //-------------------------------------------------------------------------
    // Shape validation
    //-------------------------------------------------------------------------

    assign rx_head_shape_ok =
        rx_is_head_tail
        ? ((rx_head_payload_n == 5'd0) &&
           (MAC_FLITS == 0))
        : ((rx_head_payload_n != 5'd0) ||
           (MAC_FLITS != 0));

    //=========================================================================
    // Response matching
    //=========================================================================

    assign rx_is_mem_response =
        (rx_head.msg_type == MSG_MEM_RD_RESP) ||
        (rx_head.msg_type == MSG_MEM_WR_RESP);

    assign rx_resp_tag =
        rx_head.control.raw[TXN_TAG_WIDTH-1:0];

    always_comb begin

        rx_match_slot     = '0;
        rx_response_match = 1'b0;

        if (rx_is_mem_response) begin

            if (int'(rx_resp_tag) < N_OUTSTANDING) begin

                rx_match_slot = rx_resp_tag;

                if (txn_valid_q[rx_resp_tag] &&
                    (rx_head.src_x ==
                     txn_dest_q[rx_resp_tag].x) &&
                    (rx_head.src_y ==
                     txn_dest_q[rx_resp_tag].y) &&
                    (rx_head.msg_type ==
                     txn_resp_type_q[rx_resp_tag])) begin

                    rx_response_match = 1'b1;

                end

            end

        end

    end

    //=========================================================================
    // RX outputs
    //=========================================================================

    always_comb begin

        rx_head_valid     = 1'b0;

        rx_payload_valid  = 1'b0;
        rx_payload_last   = 1'b0;
        rx_payload_data   = '0;

        rx_mac_valid      = 1'b0;

        rx_protocol_error = 1'b0;
        rx_length_error   = 1'b0;

        noc_rx_ready      = 1'b0;

        rx_src_coord  = rx_src_q;
        rx_dest_coord = rx_dest_q;
        rx_msg_type   = rx_msg_q;
        rx_control    = rx_control_q;
        rx_length     = rx_length_q;

        unique case (rx_state_q)

            //=================================================================
            // RX_IDLE
            //=================================================================

            RX_IDLE: begin

                if (rx_is_head || rx_is_head_tail) begin

                    if (!rx_head_for_us ||
                        !rx_head_shape_ok ||
                        (rx_is_mem_response &&
                         !rx_response_match)) begin

                        noc_rx_ready      = 1'b1;
                        rx_protocol_error = 1'b1;

                    end
                    else begin

                        noc_rx_ready  = rx_ready;
                        rx_head_valid = 1'b1;

                        rx_src_coord =
                            '{x: rx_head.src_x,
                              y: rx_head.src_y};

                        rx_dest_coord =
                            '{x: rx_head.dest_x,
                              y: rx_head.dest_y};

                        rx_msg_type =
                            rx_head.msg_type;

                        rx_control =
                            rx_head.control.raw;

                        rx_length =
                            rx_head.length;

                        rx_length_error =
                            rx_ready &&
                            !rx_head_len_ok;

                        rx_payload_last =
                            rx_is_head_tail;

                    end

                end
                else if (noc_rx_valid) begin

                    noc_rx_ready      = 1'b1;
                    rx_protocol_error = 1'b1;

                end

            end

            //=================================================================
            // RX_PAYLOAD
            //=================================================================

            RX_PAYLOAD: begin

                if (noc_rx_valid) begin

                    if ((noc_rx_flit.flit_type == FLIT_BODY) ||
                        (noc_rx_flit.flit_type == FLIT_TAIL)) begin

                        noc_rx_ready     = rx_ready;

                        rx_payload_valid = 1'b1;

                        rx_payload_data =
                            noc_rx_flit.flit_data;

                        rx_payload_last =
                            ((rx_payload_cnt_q + 5'd1) >=
                             rx_payload_n_q);

                    end
                    else begin

                        noc_rx_ready      = 1'b1;
                        rx_protocol_error = 1'b1;

                    end

                end

            end

            //=================================================================
            // RX_MAC
            //=================================================================

            RX_MAC: begin

                noc_rx_ready = 1'b1;

                if (noc_rx_valid &&
                    ((rx_mac_cnt_q + MAC_CNT_WIDTH'(1)) >=
                     MAC_CNT_WIDTH'(MAC_FLITS))) begin

                    rx_mac_valid = 1'b1;

                end

            end

            default: begin

                noc_rx_ready = 1'b0;

            end

        endcase

    end

    //=========================================================================
    // RX next state
    //=========================================================================

    always_comb begin

        rx_state_d = rx_state_q;

        unique case (rx_state_q)

            RX_IDLE: begin

                if (rx_is_head &&
                    rx_head_for_us &&
                    rx_head_shape_ok &&
                    !(rx_is_mem_response &&
                      !rx_response_match) &&
                    noc_rx_ready) begin

                    if (rx_head_payload_n != 5'd0) begin

                        rx_state_d = RX_PAYLOAD;

                    end
                    else if (MAC_FLITS != 0) begin

                        rx_state_d = RX_MAC;

                    end

                end

            end

            RX_PAYLOAD: begin

                if (noc_rx_valid &&
                    noc_rx_ready &&
                    ((noc_rx_flit.flit_type == FLIT_BODY) ||
                     (noc_rx_flit.flit_type == FLIT_TAIL)) &&
                    ((rx_payload_cnt_q + 5'd1) >=
                     rx_payload_n_q)) begin

                    rx_state_d =
                        (MAC_FLITS != 0)
                        ? RX_MAC
                        : RX_IDLE;

                end

            end

            RX_MAC: begin

                if (noc_rx_valid &&
                    noc_rx_ready &&
                    ((rx_mac_cnt_q + MAC_CNT_WIDTH'(1)) >=
                     MAC_CNT_WIDTH'(MAC_FLITS))) begin

                    rx_state_d = RX_IDLE;

                end

            end

            default: begin

                rx_state_d = RX_IDLE;

            end

        endcase

    end

    //=========================================================================
    // RX registers
    //=========================================================================

    always_ff @(posedge clk) begin

        if (rst) begin

            rx_state_q       <= RX_IDLE;

            rx_src_q         <= '0;
            rx_dest_q        <= '0;

            rx_msg_q         <= MSG_MEM_RD_REQ;

            rx_control_q     <= '0;
            rx_length_q      <= '0;

            rx_payload_n_q   <= '0;
            rx_payload_cnt_q <= '0;

            rx_mac_cnt_q     <= '0;
            rx_mac_tag_q     <= '0;

        end
        else begin

            rx_state_q <= rx_state_d;

            //-----------------------------------------------------------------
            // Capture accepted packet HEAD metadata.
            //-----------------------------------------------------------------

            if ((rx_state_q == RX_IDLE) &&
                (rx_is_head || rx_is_head_tail) &&
                rx_head_for_us &&
                rx_head_shape_ok &&
                !(rx_is_mem_response &&
                  !rx_response_match) &&
                noc_rx_ready) begin

                rx_src_q =
                    '{x: rx_head.src_x,
                      y: rx_head.src_y};

                rx_dest_q =
                    '{x: rx_head.dest_x,
                      y: rx_head.dest_y};

                rx_msg_q =
                    rx_head.msg_type;

                rx_control_q =
                    rx_head.control.raw;

                rx_length_q =
                    rx_head.length;

                rx_payload_n_q =
                    rx_head_payload_n;

                rx_payload_cnt_q =
                    '0;

                rx_mac_cnt_q =
                    '0;

            end

            //-----------------------------------------------------------------
            // Payload counter
            //-----------------------------------------------------------------

            if ((rx_state_q == RX_PAYLOAD) &&
                noc_rx_valid &&
                noc_rx_ready &&
                ((noc_rx_flit.flit_type == FLIT_BODY) ||
                 (noc_rx_flit.flit_type == FLIT_TAIL))) begin

                rx_payload_cnt_q <=
                    rx_payload_cnt_q + 5'd1;

            end

            //-----------------------------------------------------------------
            // MAC capture
            //-----------------------------------------------------------------

            if ((rx_state_q == RX_MAC) &&
                noc_rx_valid &&
                noc_rx_ready) begin

                rx_mac_tag_q[
                    {rx_mac_cnt_q, 5'd0} +: FLIT_WIDTH
                ] <= noc_rx_flit.flit_data;

                rx_mac_cnt_q <=
                    rx_mac_cnt_q + MAC_CNT_WIDTH'(1);

            end

        end

    end

    //=========================================================================
    // Outputs / status
    //=========================================================================

    assign rx_mac_tag = rx_mac_tag_q;

    head_flit_t tx_head_on_wire;

    assign tx_head_on_wire =
        head_flit_t'(noc_tx_flit.flit_data);

    assign tx_busy =
        (tx_state_q != TX_IDLE);

    assign rx_busy =
        (rx_state_q != RX_IDLE);

    //=========================================================================
    // Assertions
    //=========================================================================

`ifndef SYNTHESIS

    property p_tx_valid_stable;
        @(posedge clk) disable iff (rst)
        noc_tx_valid && !noc_tx_ready
        |=> noc_tx_valid;
    endproperty

    a_tx_valid_stable:
        assert property (p_tx_valid_stable)
        else $error(
            "M10: noc_tx_valid dropped before transfer completed"
        );

    property p_tx_flit_stable;
        @(posedge clk) disable iff (rst)
        noc_tx_valid && !noc_tx_ready
        |=> $stable(noc_tx_flit);
    endproperty

    a_tx_flit_stable:
        assert property (p_tx_flit_stable)
        else $error(
            "M10: noc_tx_flit changed while stalled"
        );

    property p_payload_ready_state;
        @(posedge clk) disable iff (rst)
        tx_payload_ready
        |-> (tx_state_q == TX_PAYLOAD);
    endproperty

    a_payload_ready_state:
        assert property (p_payload_ready_state)
        else $error(
            "M10: tx_payload_ready asserted outside TX_PAYLOAD"
        );

    property p_vc_constant_in_packet;
        @(posedge clk) disable iff (rst)
        (tx_state_q != TX_IDLE) &&
        (tx_state_d != TX_IDLE)
        |=> $stable(tx_vc);
    endproperty

    a_vc_constant_in_packet:
        assert property (p_vc_constant_in_packet)
        else $error(
            "M10: VC changed between packet flits"
        );

    property p_head_tail_zero_payload;
        @(posedge clk) disable iff (rst)
        (noc_tx_valid &&
         noc_tx_flit.flit_type == FLIT_HEAD_TAIL)
        |-> (tx_payload_n_q == 5'd0) &&
            (MAC_FLITS == 0);
    endproperty

    a_head_tail_zero_payload:
        assert property (p_head_tail_zero_payload)
        else $error(
            "M10: illegal HEAD_TAIL packet generated"
        );

    property p_no_deliver_and_drop;
        @(posedge clk) disable iff (rst)
        rx_protocol_error
        |-> !(rx_head_valid || rx_payload_valid);
    endproperty

    a_no_deliver_and_drop:
        assert property (p_no_deliver_and_drop)
        else $error(
            "M10: packet simultaneously delivered and rejected"
        );

    property p_error_flit_consumed;
        @(posedge clk) disable iff (rst)
        rx_protocol_error
        |-> noc_rx_ready;
    endproperty

    a_error_flit_consumed:
        assert property (p_error_flit_consumed)
        else $error(
            "M10: protocol error stalled the NoC"
        );

    property p_src_is_local;
        @(posedge clk) disable iff (rst)
        (noc_tx_valid &&
         ((noc_tx_flit.flit_type == FLIT_HEAD) ||
          (noc_tx_flit.flit_type == FLIT_HEAD_TAIL)))
        |-> (tx_head_on_wire.src_x == LOCAL_COORD.x) &&
            (tx_head_on_wire.src_y == LOCAL_COORD.y);
    endproperty

    a_src_is_local:
        assert property (p_src_is_local)
        else $error(
            "M10: injected foreign source coordinate"
        );

    property p_outstanding_bounded;
        @(posedge clk) disable iff (rst)
        $countones(txn_valid_q) <= N_OUTSTANDING;
    endproperty

    a_outstanding_bounded:
        assert property (p_outstanding_bounded)
        else $error(
            "M10: outstanding transaction count exceeded N_OUTSTANDING"
        );

    property p_no_slot_blocks_mem_request;
        @(posedge clk) disable iff (rst)
        (tx_state_q == TX_IDLE) &&
        !tx_slot_available &&
        ((tx_msg_type == MSG_MEM_RD_REQ) ||
         (tx_msg_type == MSG_MEM_WR_REQ))
        |-> !tx_ready;
    endproperty

    a_no_slot_blocks_mem_request:
        assert property (p_no_slot_blocks_mem_request)
        else $error(
            "M10: accepted memory request with no outstanding slot"
        );

    generate
        for (genvar g = 0; g < N_OUTSTANDING; g++) begin : GEN_TXN_ASSERT

            property p_valid_slot_response_type;
                @(posedge clk) disable iff (rst)
                txn_valid_q[g]
                |->
                ((txn_resp_type_q[g] == MSG_MEM_RD_RESP) ||
                 (txn_resp_type_q[g] == MSG_MEM_WR_RESP));
            endproperty

            a_valid_slot_response_type:
                assert property (p_valid_slot_response_type)
                else $error(
                    "M10: invalid expected response type in slot %0d",
                    g
                );

        end
    endgenerate

    property p_matched_response_has_valid_slot;
        @(posedge clk) disable iff (rst)
        rx_response_match
        |-> txn_valid_q[rx_match_slot];
    endproperty

    a_matched_response_has_valid_slot:
        assert property (p_matched_response_has_valid_slot)
        else $error(
            "M10: response matched an invalid transaction slot"
        );

    property p_matched_response_source;
        @(posedge clk) disable iff (rst)
        rx_response_match
        |->
        (rx_head.src_x == txn_dest_q[rx_match_slot].x) &&
        (rx_head.src_y == txn_dest_q[rx_match_slot].y);
    endproperty

    a_matched_response_source:
        assert property (p_matched_response_source)
        else $error(
            "M10: matched response source does not match request destination"
        );

    property p_matched_response_type;
        @(posedge clk) disable iff (rst)
        rx_response_match
        |->
        (rx_head.msg_type ==
         txn_resp_type_q[rx_match_slot]);
    endproperty

    a_matched_response_type:
        assert property (p_matched_response_type)
        else $error(
            "M10: matched response type is incorrect"
        );

`endif

endmodule